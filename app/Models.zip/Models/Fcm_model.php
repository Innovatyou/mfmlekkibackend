<?php

namespace App\Models;

use CodeIgniter\Model;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;

class Fcm_model extends Model
{
  protected $db;
  public $status = 'error';
  public $message = 'Error processing requested operation.';
  public $role = 0;
  private $cloudMessaging;

  public function __construct()
  {
    parent::__construct();
    $session = session();
    $this->role = $session->get('role');
    $apitoken = $session->get('apitoken');
    $factory = (new Factory)
      ->withServiceAccount('./uploads/firebase.json');
    $this->cloudMessaging = $factory->createMessaging();
  }

  function testnotifications($apitoken)
  {
    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    // var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $this->createNotificationMessage($tokens);
    }
  }

  function createNotificationMessage($tokens)
  {
    $data = array('title' => "hello world", 'action' =>  "inbox", 'inbox' => json_encode([]));


    $message = CloudMessage::new();
    $message = $message->withData($data);
    $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens);
    var_dump($sendReport);
  }

  function storeUserFcmToken($token)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_fcm_token');
    $token['date'] = date('Y-m-d H:i:s');
    $builder->insert($token);
    //$insert_id = $builder->insert_id();
    $this->status = 'ok';
    $this->message = 'token added successfully';
  }

  function updateUserFcmToken($token, $version)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_fcm_token');
    $data['app_version'] = $version;
    $builder->where('token', $token);
    $builder->update($data);
    $this->status = 'ok';
    $this->message = 'token updated successfully';
  }

  function androidUsersTokenListing($apitoken)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_fcm_token');
    $builder->select('tbl_fcm_token.token');
    $builder->where('apitoken', $apitoken);
    $query = $builder->get();
    //var_dump($query); die;
    $result =  $query->getResult();
    //var_dump($result); die;
    $token = [];
    foreach ($result as $res) {
      array_push($token, $res->token);
    }
    //var_dump($token); die;
    return $token;
  }

  function AllUsersSocialTokenListing($email = "null", $apitoken = "")
  {
    //$builder->select('tbl_social_fcm_tokens.token');
    //$builder->from('tbl_social_fcm_tokens');

    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_social_fcm_tokens');
    $builder->select('tbl_social_fcm_tokens.token');
    $builder->where('apitoken', $apitoken);
    $builder->where('email !=', $email);
    $query = $builder->get();
    //var_dump($query); die;
    $result =  $query->getResult();
    //var_dump($result); die;
    $token = [];
    foreach ($result as $res) {
      array_push($token, $res->token);
    }
    //var_dump($token); die;
    return $token;
  }

  function usersSocialTokenListing($email, $apitoken)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_social_fcm_tokens');
    $builder->select('tbl_social_fcm_tokens.token');
    $builder->where('apitoken', $apitoken);
    $builder->where('email', $email);
    $query = $builder->get();
    //var_dump($query); die;
    $result =  $query->getResult();
    //var_dump($result); die;
    $token = [];
    foreach ($result as $res) {
      array_push($token, $res->token);
    }
    //var_dump($token); die;
    return $token;
  }

  public function sendPushNotificationToFCMSever($API_SERVER_KEY, $title, $message, $apitoken)
  {

    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    // var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      // var_dump($tokens[$i]); die;
      $fields = array(
        'registration_ids' => $tokens[$i],
        'priority' => 10,
        'notification' => array('title' => $title, 'body' =>  $message),
      );
      $fields['time_to_live'] = 1200;
      //$fields['time_to_live'] = 3600000;
      $this->push_data($API_SERVER_KEY, $fields);
    }
  }

  public function sendUserRelatedPushNotification($API_SERVER_KEY, $email, $action, $apitoken)
  {
    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    // var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      // var_dump($tokens[$i]); die;
      $data = array('email' => $email, 'action' =>  $action);
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }


  public function newMediaNotification($API_SERVER_KEY, $title, $media, $apitoken)
  {

    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    // var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => $title, 'action' =>  "newMedia", 'media' => json_encode($media));
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function push_event_data($API_SERVER_KEY, $event, $apitoken)
  {
    //var_dump($article); die;
    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    // var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => $event->title, 'action' =>  "events", 'events' => json_encode($event));
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens);
    }
  }

  public function push_item_data($API_SERVER_KEY, $item, $type, $apitoken)
  {
    //var_dump($article); die;
    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    // var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => $item->title, 'id' => $item->id, 'action' =>  $type);
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function push_inbox_data($API_SERVER_KEY, $inbox, $apitoken)
  {
    //var_dump($inbox); die;
    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => $inbox->title, 'action' =>  "inbox", 'inbox' => json_encode($inbox));
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function liveStreamsNotification($API_SERVER_KEY, $livestream, $apitoken)
  {
    // var_dump($livestream); die;
    $tokens = array_chunk($this->androidUsersTokenListing($apitoken), 1000);
    // var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => $livestream->title, 'action' =>  "livestream", 'livestream' => json_encode($livestream));
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function userActionsNotification($API_SERVER_KEY, $email, $avatar, $msg, $apitoken)
  {
    // var_dump($livestream); die;
    $tokens = array_chunk($this->usersSocialTokenListing($email, $apitoken), 1000);
    //var_dump($tokens); die;
    //var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => "New Notification", 'action' =>  "social_notify", 'email' => $email, 'avatar' => $avatar, 'message' => $msg);
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function userConversationNotification($API_SERVER_KEY, $email, $user, $unseen, $chat, $apitoken)
  {
    // var_dump($livestream); die;
    $tokens = array_chunk($this->usersSocialTokenListing($email, $apitoken), 1000);
    //var_dump($tokens); die;
    //var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => $email, 'action' =>  "chat", 'chat' => json_encode($chat), 'user' => json_encode($user));
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function userSeenConversationNotification($API_SERVER_KEY, $email, $recipient, $chatid, $apitoken)
  {
    // var_dump($livestream); die;
    $tokens = array_chunk($this->usersSocialTokenListing($email, $apitoken), 1000);
    //var_dump($tokens); die;
    //var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => "Read Conversation", 'action' =>  "read_conversation", 'email' => $recipient, 'chatid' => $chatid);
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function userTypingNotification($API_SERVER_KEY, $email, $recipient, $apitoken)
  {
    // var_dump($livestream); die;
    $tokens = array_chunk($this->usersSocialTokenListing($email, $apitoken), 1000);
    //var_dump($tokens); die;
    //var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data =  array('title' => "Read Conversation", 'action' =>  "user_typing", 'email' => $recipient);
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  public function notifyUserOnlinePresence($API_SERVER_KEY, $email, $status, $apitoken)
  {
    // var_dump($livestream); die;
    $tokens = array_chunk($this->AllUsersSocialTokenListing($email, $apitoken), 1000);
    //var_dump($tokens); die;
    //var_dump(sizeof($tokens)); //die;
    for ($i = 0; $i < sizeof($tokens); $i++) {
      $data = array('title' => "Online Status", 'action' =>  "online_status", 'email' => $email, 'status' => $status, 'last_seen' => time());
      $message = CloudMessage::new();
      $message = $message->withData($data);
      $sendReport = $this->cloudMessaging->sendMulticast($message, $tokens[$i]);
    }
  }

  private function push_data($API_SERVER_KEY, $fields)
  {
    //echo $API_SERVER_KEY; die;
    $path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
    $headers = array(
      'Authorization:key=' . $API_SERVER_KEY,
      'Content-Type:application/json'
    );
    // Open connection
    $ch = curl_init();
    // Set the url, number of POST vars, POST data
    curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    // Execute post
    $result = curl_exec($ch);
    //var_dump($result); die;
    // Close connection
    curl_close($ch);
    $res = json_decode($result);
    //var_dump($res); die;
    //var_dump($res->results[0]->error);
    if (isset($res->results[0]->error) && $res->results[0]->error != 'NotRegistered') { //NotRegistered, common error when a user uninstalls the app causing the token to be invalide
      $this->status = "error";
      $this->message = $res->results[0]->error;
    } else {
      $this->status = "ok";
      $this->message = "Message sent Successfully";
    }
  }
}
