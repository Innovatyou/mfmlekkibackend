<?php

namespace App\Models;

use App\Models\Basemodel;

class Media_model extends Basemodel
{
  public $status;
  public $message;

  public function __construct()
  {
    parent::__construct();
    $this->status = $this->applocal['error'];
    $this->message = $this->applocal['process_error'];
  }

  public function searchListing($query, $offset, $email, $apitoken)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_media');
    $builder->select('tbl_media.*');
    $builder->where('apitoken', $apitoken);
    $builder->where("(`title` LIKE '%$query%'");
    $builder->orwhere("`description` LIKE '%$query%')");
    $builder->orderby('dateInserted', 'desc');
    $builder->limit(30, $offset);

    $query = $builder->get();
    $result = $query->getResult();
    foreach ($result as $res) {
      $res->cover_photo = $this->get_thumbnail_source($res->cover_photo, $apitoken);
      $res->stream = $this->get_media_source($res->type, $res->video_type, $res->source, $apitoken);
      $res->download = $this->get_media_source($res->type, $res->video_type, $res->source, $apitoken);
      $res->comments_count = 0; //$this->get_total_comments($res->id);
      $res->user_liked = 0; //$this->checkIfUserLikedMedia($res->id,$email);
    }
    return $result;
  }

  public function update_media_total_views($media, $apitoken)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_media');
    $builder->where('apitoken', $apitoken);
    $builder->set('views_count', 'views_count+1', FALSE);
    $builder->where('id', $media);
    $builder->update();
  }


  function getLatestMedia($apitoken)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_media');
    $builder->select('tbl_media.*');
    $builder->where('apitoken', $apitoken);
    $builder->orderby('dateInserted', 'desc');
    $builder->limit(10);
    $query = $builder->get();
    $result = $query->getResult();
    foreach ($result as $res) {
      $res->cover_photo = $this->get_thumbnail_source($res->cover_photo, $apitoken);
      $res->stream = $this->get_media_source($res->type, $res->video_type, $res->source, $apitoken);
      $res->download = $this->get_media_source($res->type, $res->video_type, $res->source, $apitoken);
      $res->comments_count = 0; //$this->get_total_comments($res->id);
      $res->user_liked = 0; //$this->checkIfUserLikedMedia($res->id,$email);
    }
    return $result;
  }

  public function fetch_media($type, $page = 0, $email = "null", $apitoken = "")
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_media');
    $builder->select('tbl_media.*');
    $builder->where('apitoken', $apitoken);
    $builder->where('type', $type);
    $builder->orderby('id', 'desc');
    if ($page != 0) {
      $builder->limit(20, $page * 20);
    } else {
      $builder->limit(20);
    }
    $query = $builder->get();
    $result = $query->getResult();
    foreach ($result as $res) {
      $res->cover_photo = $this->get_thumbnail_source($res->cover_photo, $apitoken);
      $res->stream = $this->get_media_source($res->type, $res->video_type, $res->source, $apitoken);
      $res->download = $this->get_media_source($res->type, $res->video_type, $res->source, $apitoken);
      $res->comments_count = 0; //$this->get_total_comments($res->id);
      $res->user_liked = 0; //$this->checkIfUserLikedMedia($res->id,$email);
    }
    return $result;
  }

  public function get_total_media($type, $apitoken)
  {
    $db = \Config\Database::connect("default");
    $builder = $db->table('tbl_media');
    $builder->select("COUNT(*) as num");
    $builder->where('apitoken', $apitoken);
    $builder->where('type', $type);
    $query = $builder->get();
    $result = $query->getRow(0);
    if (isset($result)) return $result->num;
    return 0;
  }


  private function get_thumbnail_source($source, $apitoken)
  {
    if ($this->isValidURL($source)) {
      return $source;
    }
    return base_url() . "/uploads/thumbnails/" . $apitoken . "/" . $source;
  }

  private function get_media_source($type, $video_type, $source, $apitoken)
  {
    if ($this->isValidURL($source)) {
      return $source;
    }
    if ($type == "audio") {
      return base_url() . "/uploads/audios/" . $apitoken . "/" . $source;
    } else {
      if ($video_type == "mp4_video") {
        return base_url() . "/uploads/videos/" . $apitoken . "/" . $source;
      }
      return $source;
    }
  }

  function isValidURL($url)
  {
    return filter_var($url, FILTER_VALIDATE_URL);
  }
}
